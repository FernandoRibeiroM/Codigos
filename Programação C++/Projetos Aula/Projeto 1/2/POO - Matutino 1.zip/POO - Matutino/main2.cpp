#include <iostream>
#include <locale>

#include "Aluno.h"
#include "disciplina.h"

using namespace std;

void limpar_buffer();

//--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
int main(int argc, char** argv) {
	
	setlocale(LC_ALL, "");
	system("chcp 1252 > nul");
	
	int N_alunos;
	int i;

	cout << "\n\tCadastro de aluno" << endl << endl;
	cout << "Digite a quantidade de alunos: ";
	cin >> N_alunos;
	cout << endl;
	limpar_buffer();
	
	Aluno *Lista_alunos[N_alunos];
	for( i = 0; i < N_alunos; i++){
		Lista_alunos[i] = NULL;		
	}	

	
//--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	for( i = 0; i < N_alunos; i++){		
	
	cout << endl;
	
	Aluno *aluno = new Aluno();
	string nome;
	cout << "Digite o Nome do aluno: "; 
	getline(cin, nome);
	limpar_buffer();
	aluno->setNome(nome);
	cout << endl;
	
	int matricula;
	do{
		cout << "Digite a matr�cula: ";
		
		cin >> matricula;
		cout << endl;
		limpar_buffer();
		if(matricula < 0){
			cout << "Valor inv�lido, digite novamente\n";
		}
	}while(matricula < 0);
	aluno->setMatricula(matricula);

	cout << "Digite o CPF do aluno: ";
	long long cpf;
	cin >> cpf;
	aluno->setCpf(cpf);
	cout << endl;
	limpar_buffer();

	
	cout << "Digite a data de nascimento do aluno : ";
	string data_nascimento;
	cin >> data_nascimento;
	aluno->setData_nascimento(data_nascimento);
	cout << endl;
	limpar_buffer();

	
	cout << "Digite o sexo do aluno (H - Homem ou M - mulher): ";
	char sexo;
	cin >> sexo;
	aluno->setSexo(sexo);
	cout << endl;
	limpar_buffer();

	int bolsista;
	do{
	cout << "Digite se o aluno � bolsista (1- sim ou 2- n�o ou 3- Em precesso): ";
	cin >> bolsista;
	cout << endl;
	limpar_buffer();
	}while(bolsista >= 4 || bolsista <= 0);
	aluno->setBolsista(bolsista);
	
	Lista_alunos[i] = aluno;
	system ("pause > nul");
	system ("cls");
	
	cout << endl;

	}
//--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

	for( i = 0; i < N_alunos; i++){
		Aluno *aluno = 	Lista_alunos[i];
		aluno->Imprimir_Informacoes_Aluno();
	}
	
	for( i = 0; i < N_alunos; i++){
		delete Lista_alunos[i];
	}
		

	return 0;
}

void limpar_buffer(){
	cin.clear();
	fflush(stdin);
}

